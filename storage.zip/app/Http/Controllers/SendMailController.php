<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

class SendMailController extends Controller
{
    public function index()
    {
        return view('email');
    }

    public function store(Request $request)
    {
        $tes = $request->tes;
        require '..\vendor/autoload.php';
        $mail = new PHPMailer(true);
        $mail->SMTPDebug = 0;
        $mail->isSMTP();
        $mail->Host = env('EMAIL_HOST');
        $mail->SMTPAuth = '';
        $mail->Username = env('EMAIL_USERNAME') ;
        $mail->Password = env('EMAIL_PASSWORD');
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        $mail->setFrom($tes, $tes);
        $mail->addAddress('testing.paboi@gmail.com');
        $mail->isHTML(true);
        $mail->Subject = 'subject';
        $mail->Body = 'body';
        $dt = $mail->send();

        if($dt){
            return 'berhasil';
        }else{
            return 'gagal';
        }
    }
}
