<form action="/store" method="post">
    @csrf
    <input type="text" name="tes">
    <input type="submit" value="kirim email"/>
</form>