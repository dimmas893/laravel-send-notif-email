<form action="/store" method="post">
    <?php echo csrf_field(); ?>
    <input type="text" name="tes">
    <input type="submit" value="kirim email"/>
</form><?php /**PATH C:\xampp\htdocs\mentahan\send_mail\resources\views/email.blade.php ENDPATH**/ ?>